<ul>
 <?php echo $logger;?>
</ul>