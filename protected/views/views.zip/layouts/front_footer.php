<?php 
/*add global variables to footer*/
ScriptManager::registerGlobalVariables();
?>
</body>
</html>