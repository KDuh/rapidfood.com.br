<?php $this->renderPartial('/layouts/front_header');?>

<!--MAIN CONTENT-->
<?php echo $content;?>

<?php $this->renderPartial('/layouts/front_footer');?>