<?php 
?>

<div class="orange_header">
	<p class="center title"><?php echo t("Ideal")?></p>		
</div> <!-- orange_header-->

<div class="container text-center stripe_ideal_receipt">
    <h2><?php echo t("Something went wrong")?></h2>
    <p class="text-danger"><?php echo $message?></p>
    
    <i class="ion-close-circled"></i>
</div> <!--container-->