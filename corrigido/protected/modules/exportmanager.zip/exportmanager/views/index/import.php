

<?php echo CHtml::beginForm(); ?>

<h3><?php echo t("Import Merchant")?></h3>  

<a id="upload-file" href="javascript:;" class="btn btn-default"><?php echo t("Browse")?></a>

<div class="display-merchant-wrap"></div> 

<?php echo CHtml::endForm(); ?>